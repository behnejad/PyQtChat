pyChat
======

A simple chat room, using TCP socket, made for educational purpose.

Usage
-------------
Run server.py for listening, then run client.py and type.
