# David Mason
# 5/17/2011

import json, httplib, urllib2

class SmartRedirectHandler(urllib2.HTTPRedirectHandler):     
  def http_error_301(self, req, fp, code, msg, headers):  
    result = urllib2.HTTPRedirectHandler.http_error_301( 
	self, req, fp, code, msg, headers)              
    result.status = code                                 
    return result                                       

  def http_error_302(self, req, fp, code, msg, headers):   
    result = urllib2.HTTPRedirectHandler.http_error_302(
	self, req, fp, code, msg, headers)              
    result.status = code                                
    return result      

class DefaultErrorHandler(urllib2.HTTPDefaultErrorHandler):    
  def http_error_default(self, req, fp, code, msg, headers): 
    result = urllib2.HTTPError(                           
	req.get_full_url(), code, msg, headers, fp)       
    result.status = code                                   
    return result   

def webGet(url, args):
  withArgs = url + '?'
  for key in args:
    withArgs = withArgs + str(key).replace(' ','%20') + '=' + str(args[key]).replace(' ','%20') + '&'
  
  request = urllib2.Request(withArgs)
  request.add_header('accept', 'application/json')
  opener = urllib2.build_opener(SmartRedirectHandler(), DefaultErrorHandler())
  return opener.open(request).read()
  
def webInvoke(host, method, args):
    print json.dumps(args)
    h = httplib.HTTPConnection(host)
    h.request('POST', method, json.dumps(args))
    r = h.getresponse()
    return r.read()
  
def main():
  url = 'localhost:8080'
  webInvoke(url,'sendMessage', {'source':'dave','dest':'cocoa','message':'A message!'})
  webInvoke(url,'sendMessage', {'source':'dave','dest':'cocoa','message':'Another message!'})
  webInvoke(url,'sendMessage', {'source':'dave','dest':'cocoa','message':'A third message!'})
  response = webInvoke(url, 'getMessages', {'name':'cocoa'})
  print response
  print type(response)
  
if __name__ == '__main__':
  main()