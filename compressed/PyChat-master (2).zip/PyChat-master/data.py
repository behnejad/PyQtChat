# David Mason
# 5/17/2011


from random import randint
import json

class Data():
  messages = {}
  
  def __init__(self):
    print 'initializing data source'
  
  def register(self, name):
    return json.dumps(1)
    
  def putMessage(self, source, dest, message):
    if dest not in self.messages:
      self.messages[dest] = []
    self.messages[dest].append((source, message))
    return json.dumps(1)
    
  def getMessages(self, name):
    if name in self.messages:
      return json.dumps(self.messages.pop(name))
    else:
      return json.dumps([])
  