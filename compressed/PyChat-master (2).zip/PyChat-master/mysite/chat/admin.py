from chat.models import Message
from django.contrib import admin

admin.site.register(Message)
