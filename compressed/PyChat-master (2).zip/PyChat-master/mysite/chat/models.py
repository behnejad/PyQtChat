from django.db import models

class Message(models.Model):
  message = models.CharField(max_length=1024)
  source = models.CharField(max_length=20)
  dest = models.CharField(max_length=20)
  sent_date = models.DateTimeField('date sent')
  