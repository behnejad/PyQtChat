# David Mason
# 5-17-2011

import cherrypy
from cherrypy import expose
from data import Data

class Hello:
  data = Data()
  
  def __init__(self):
    cherrypy.request.processRequestBody = False
  
  @expose
  def sendMessage(self, source, dest, message):
    return self.data.putMessage(source, dest, message)
    
  @expose
  def getMessages(self, name):
    return self.data.getMessages(name)
  
def main():
  conf = { '/' : {
                     'server.socket_host':'0.0.0.0', 
                    }
           }
  cherrypy.quickstart(Hello(), '/', conf)
  
if __name__ == '__main__':
  main()
