"""
NAME 
    gui - Graphic User Interface

DESCRIPTION
    gui is a collection of frames and dialogs based on wxPython library for interaction     with user

PACKAGE CONTENTS
    chatview

    connectiondlg

    errordlg

    logindlg

    createnewdlg

    settingsdlg  

"""
