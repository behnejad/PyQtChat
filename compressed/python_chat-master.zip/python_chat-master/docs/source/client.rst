.. chat documentation master file, created by
   sphinx-quickstart on Fri Jul 29 14:03:37 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


Client Documentation
================================

.. automodule:: client
   :members:

