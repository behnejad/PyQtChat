.. chat documentation master file, created by
   sphinx-quickstart on Fri Jul 29 14:03:37 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


Chat Protocol Documentation
===========================

.. automodule:: protocol

clientprotocol
--------------

.. automodule:: clientprotocol
   :members:

serverprotocol
--------------

.. automodule:: serverprotocol
   :members:

basecmd
--------

.. automodule:: basecmd
   :members:

accountsclass
--------------

.. automodule:: accountsclass
   :members:


myparser
--------

.. automodule:: myparser
   :members:
