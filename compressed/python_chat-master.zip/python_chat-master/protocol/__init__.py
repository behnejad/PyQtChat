"""
Protocol package

PACKAGE CONTENTS
    clientprotocol

    serverprotocol

    basecmd

    accountsclass

    myparser

"""
