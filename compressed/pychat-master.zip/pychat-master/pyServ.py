import time, socket, select
from threading import Thread

class servSock():

    # Initializing servSock() after being given hostname and port
    # I've made the message length 140 characters for arbitrary reason

    def __init__(self, hostname, port):
        self.USERLENGTH = 15
        self.MSGLENGTH = 1064
        self.CONNECTION_LIST = []
    
        self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.s.bind((hostname, port))
        self.s.listen(10)
        
        self.CONNECTION_LIST.append(self.s)

        self.pooling()
    
    # Main loop for server to accept a client and pass it off to a thread.
    def pooling(self):

        while True:

            read_sockets, write_sockets, error_sockets = select.select(self.CONNECTION_LIST, [], [])

            for sock in read_sockets:
                
                if sock == self.s:
                    (clientsock, addr) = self.s.accept()
                    username = clientsock.recv(self.USERLENGTH)
                    print username + " has connected."
                    self.CONNECTION_LIST.append(clientsock)
                
                else:
                    try:
                        data = sock.recv(self.MSGLENGTH)
                        if data:
                            self.display_all(str(sock) + ": " + data, sock)
                    except:
                        self.display_all(str(sock) + " is offline.", sock)
                        sock.close()
                        self.CONNECTION_LIST.remove(sock)
                        continue

    def display_all(self, msg, sock):
        for socket in self.CONNECTION_LIST:
            if socket != self.s and socket != sock:
                try: 
                    socket.send(msg)
                except:
                    socket.close()
                    self.CONNECTION_LIST.remove(socket)
                
s = servSock('localhost', 4848)
