import time, socket, sys, select
from threading import Thread

class clisock():

    def __init__(self, hostname, address):
        
        self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        try:
            self.s.connect((hostname, address))
        except:
            print "Could not connect to server. Please try again."
            sys.exit()            

        self.MSGLEN = 1064
        print "Please enter a username: ", 
        self.username = raw_input()
        self.s.sendall(self.username)
        
        self.prompt()
        self.chatloop()

    def chatloop(self):
        
        while True:
            socket_list = [sys.stdin, self.s]
            
            read_sockets, write_sockets, error_sockets = select.select(socket_list, [], [])
            for sock in read_sockets:
                
                if sock == self.s:
                    data = sock.recv(self.MSGLEN)
                    if not data:
                        print '\nDisconnected from chat server'
                        sys.exit()
                    else:
                        sys.stdout.write(data)
                        self.prompt()
                else:
                    msg = sys.stdin.readline()
                    self.s.send(msg)
                    self.prompt()

    def prompt(self):
        sys.stdout.write('<' + self.username + '> ')
        sys.stdout.flush()
c = clisock('localhost', 4848)
