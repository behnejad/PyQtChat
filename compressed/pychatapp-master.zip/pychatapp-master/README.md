PyChatApp
=========

A simple Chat App written in python<br>
Grab latest PyChatserver.py and just run "python PyChatserver.py"
<br>How to use client:
<br>- Linux: Open terminal and type "python PyChatclient.py localhost"
<br>NB! Arch linux has python 2.7 as "python2"
<br>- Windows: (never tested)<br>
TODO:<br>
- [ ] Edit server and client so they can send text any time<br>
- [ ] Create web interface<br>
- [x] fork arti95 broker.py<br>
- [ ] make arti95 broker.py usable(for me)<br>
- [x] Fix bug of first PyChat<br>
- [x] Clean repo
